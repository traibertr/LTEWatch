The steps for adding Fractus Antennas symbols are:

     Once the AWR software is open:
�	Go to �Help�
�	Click on �Show Files/Directories� -> a list of files and directories is opened
�	Double-click on folder �Appdatauser� -> the corresponding folder is opened
�	If a "Symbols" folder does not exist in the "Appdatauser" folder, just create it !! If it already exists you do not need to create it
�	Finally, double-click on �Symbols� folder and add/copy here the .syf files you've received together with this Readme.
