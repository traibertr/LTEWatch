What is inside this folder?
1. Footprint folder: 
- Contains the NN03-310 antenna footprint.

2. LibrarieS folder: 
- Contains the library files of the NN components for different RF CAD Sofwares. 
- Contains its User Manuals. 

3. Step File: 
- Contains the NN03-310 antenna Step File.

4. CST Studio Suite Encrypted Files folder: 
- Contains the NN03-310 encrypted antenna file for CST Studio Suite. 
- Contains its User Manual. 
- Contains its PCN (Product Change Notification).